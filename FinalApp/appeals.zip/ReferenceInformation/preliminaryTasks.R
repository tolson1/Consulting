#Row binded DCT and PATO datasets into a single .csv file
appeals <- read.csv("appeals.csv", header = T, stringsAsFactors = F)
#1) Change date to correct form for SQLite (yyyy-mm-dd)
appeals$Date <- as.Date(appeals$Date, "%m/%d/%Y")

#2) Make sure all characters are UTF-8
appeals$Case.Name <- enc2utf8(as.character(appeals$Case.Name))

#3) Write to text file with "|" as the delimiter
write.table(appeals, file = "appeals.txt", sep = "|", row.names = F, quote = F, col.names = F)
